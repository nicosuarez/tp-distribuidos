if ($] >= 5.00){
	print "$]";
}
else{
	print "ERROR";
}

