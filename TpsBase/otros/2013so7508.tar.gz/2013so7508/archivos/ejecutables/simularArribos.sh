#!/bin/bash
cp "$CONFDIR/../../archivos/originales/acepdir/"* $ARRIDIR
